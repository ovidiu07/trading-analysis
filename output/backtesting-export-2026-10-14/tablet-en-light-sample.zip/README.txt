Backtesting export: Five Sessions GER40 Replay
Generated at (UTC): 2026-10-14T09:52:41.367Z
Inclusive entry date period: 2025-10-06 to 2025-10-06. Dates use each trade's recorded local clock.
Exported trades: 3. Analytics trades: 3. Excluded trades retained in trades.csv: 0.
trades.csv: one row per trade, with entry and exit details and every available API trade field. Live trades are excluded.
overview.csv and edge-analysis.csv: recomputed from included trades in the selected period; saved lifetime analytics are not reused.
periods.csv: daily, Monday-Sunday weekly and monthly groups using exit date, falling back to entry date when exit date is absent.
Period groups contain only this export sample; boundary weeks/months may be partial and entry-period selection can include later exits.
saved-edge-lenses.csv: saved filter definitions applied within the export sample, including their own saved entry-date bounds. Unsupported filters are explicitly flagged.
screenshots.csv: metadata for screenshots linked to exported trades. Image files and temporary signed URLs are not included.
workspace.json: workspace notes, strategy context, export settings and coverage. Workspace statistics are an all-time snapshot; overview.csv contains period results.
SL/TP hit date and time use only an explicit SL/TP exit signal and recorded exit timestamp. Result alone does not establish an SL/TP hit.
Planned SL/TP prices and order placement/amendment timestamps are not stored by this trade model and cannot be exported.
Missing fields are blank. Source timezone is blank when unspecified; no timezone conversion is applied. Gap timestamps contain time only as stored.
Planned R:R and realized R are separate stored fields. R is never inferred from cash, outcome, prices or planned R:R.
R totals, expectancy and drawdown are blank when R coverage is incomplete. Empty analytics samples have blank performance values.
Cash results use known net PnL separately for each currency without FX conversion. Cash coverage is known PnL / trades with that currency.
Metric sample size identifies the known-value sample. Cash win rate uses outcomes of that sample. missingCash in workspace.json also counts unknown currencies.
Commission and excursions use the stored PnL currency; the trade model does not separately store the price/position-value quote currency.
Profit factor is blank when profits exist without losses. Net PnL already includes reported costs; commission is not subtracted again.
Source cumulative PnL is preserved as reported by the import and is not reset to this period.
Edge groups and tags overlap; do not sum across dimensions. Sample size bands describe counts and do not establish a validated trading edge.
CSV files use UTF-8 with BOM, comma separators, quoted fields, ISO dates and decimal points. Text starting with spreadsheet formula characters is prefixed with an apostrophe.
